#ifndef _USER_PWM_H
#define _USER_PWM_H
#include "cpu.h"
#include "config.h"
#include "typedef.h"

#define LOG_TAG_CONST       NORM
#define LOG_TAG             "[normal]"
#include "debug.h"
enum{
    //用来标记结构体PWM_VAR成员是哪个pwm类型
    //AD150有六路PWM,所以USER_PWM0_CH~USER_PWM5_CH,如果需要移植可以自己修改
    USER_TIMER_NONE,
    USER_PWM0_CH,
    USER_PWM1_CH,
    USER_PWM2_CH,
    USER_PWM3_CH,
    USER_PWM4_CH,
    USER_PWM5_CH,
};

//pwm模块控制消息
enum{
    //开关PWM消息
    PWM_STATE_OPEN, 
    PWM_STATE_CLOSE,

    //动态加载引脚消息
    PWM_STATE_ADD_PORT,
    PWM_STATE_DEL_PORT,

};


//开关引脚是否输出PWM
enum{
    PORT_CONFIG_NONE,

    //下面八个为CHx消息,引脚映射需要调用这八个
    PORT_OUTPUT_CH0_STATE_OPEN,
    PORT_OUTPUT_CH1_STATE_OPEN,
    PORT_OUTPUT_CH2_STATE_OPEN,
    PORT_OUTPUT_CH3_STATE_OPEN,
    PORT_OUTPUT_CH0_STATE_CLOSE,
    PORT_OUTPUT_CH1_STATE_CLOSE,
    PORT_OUTPUT_CH2_STATE_CLOSE,
    PORT_OUTPUT_CH3_STATE_CLOSE,

    //硬件引脚或者已初始化过或者动态加载的映射引脚可以直接调用下面两个消息
    PORT_PWM_STATE_OPEN,  
    PORT_PWM_STATE_CLOSE,
};

#define PWM_PORT_MAX  3 //映射最大引脚数量，理论上没有限制个数

typedef struct
{
    u8  pwm_modula_enable;  //pwm模块开关
    u16 freq;  //PWM频率
    u16 duty;  //PWM占空比
    u16 pwm_type; //PWM类型，例如USER_PWM0_CH
    u8  pwm_output_state; //pwm输出状态
    u16 output_clk; //当采用映射方式时候例如CH0_CH0_PWM，选择映射源
    s16 port[PWM_PORT_MAX]; //当选择输出的引脚
}PWM_VAR;


//配置多少路PWM输出
typedef struct
{
    PWM_VAR timer2_pwm0;
    PWM_VAR timer2_pwm1;
    PWM_VAR mcpwm0;
    PWM_VAR mcpwm1;
    PWM_VAR mcpwm2;
    PWM_VAR mcpwm3;
}ALL_PWM_VAR;

extern void pwm_ctr_pwm_state(u16 cmd,PWM_VAR *pwm_var);
extern void pwm_gpio_pwm_state(u16 gpio,u16 cmd);
extern void pwm_ctr_init(void);
extern void set_pwm_duty_and_freq(PWM_VAR *pwm_var);

#endif
