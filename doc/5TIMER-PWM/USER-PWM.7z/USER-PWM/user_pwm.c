/*********************************************************************************************
    *   Filename        : user_pwm.c

    *   Description     : PWM驱动模块

    *   Author          : JL_lihongyuan

    *   Email           :

    *   Last modifiled  : 2021-6-21

    *   Copyright:(c)JIELI  2011-2021  @ , All Rights Reserved.
*********************************************************************************************/
//AD150 timer2_pwm0 and timer2_pwm1 使用同一个timer所以频率一样占空比不同,使用时候需要自己修改
//!!!!!!注意!!!!!!,!!!!!!注意!!!!!!,使用模块前先看下每个函数的介绍再使用,!!!!!!注意!!!!!!,!!!!!!注意!!!!!!
#include "user_pwm.h"
#include "app_config.h"

extern u32 sys_clock_get(void);
void pwm_ctr_pwm_state(u16 cmd,PWM_VAR *pwm_var);
void pwm_gpio_pwm_state(u16 gpio,u16 cmd);
void pwm_ctr_init(void);
void set_pwm_duty_and_freq(PWM_VAR *pwm_var);
static void set_pwm_timer_state(u16 cmd,PWM_VAR *pwm_var);
static void set_hw_port_iomap_reg(u16 cmd,PWM_VAR *pwm_var);
static u8 port_set_hw_and_iomap_state(u16 cmd,u16 gpio,PWM_VAR *pwm_var);

static u16 USER_PWM_HW_PORT[6] = {IO_PORTA_03,IO_PORTA_02,IO_PORTA_06,IO_PORTA_07,IO_PORTA_11,IO_PORTA_12};  //六路pwm硬件引脚
static u8  USER_PWM_HW_PORT_IOMAP_REG[6] = {15,16,16,17,18,19}; //硬件pwm引脚输出关于IOMC寄存器设置位，参考用户手册
static u16 gpio_output_channle_pwm_state[IO_PORT_MAX] = {PORT_CONFIG_NONE}; //主要是用来标记引脚映射到哪个通道
static s16 output_clk_sel[4] = {-1,-1,-1,-1};  //四路映射通道标记,主要是为了防止多次映射到同个通道导致输出异常

//该结构体变量只是提供参考,AD150有六路PWM所以这里定义6个成员,如果不需要可以自己创建PWM_VAR然后调用pwm_ctr_pwm_state函数
ALL_PWM_VAR all_pwm_var = {  //六路PWM初始化信息
    .timer2_pwm0 = {
        .pwm_modula_enable = false,
        .freq = 2000,
        .duty = 3000,
        .pwm_type = USER_PWM0_CH,
        .pwm_output_state = PWM_STATE_CLOSE,
        .output_clk = CH0_T2_PWM_OUT0,
        .port[0] = IO_PORTA_03,
        .port[1] = -1,
        .port[2] = -1,
    },
    .timer2_pwm1 = {
        .pwm_modula_enable = false,
        .freq = 2000,
        .duty = 5000,
        .pwm_type = USER_PWM1_CH,
        .pwm_output_state = PWM_STATE_CLOSE,
        .output_clk = CH1_T2_PWM_OUT1,
        .port[0] = IO_PORTA_02,
        .port[1] = -1,
        .port[2] = -1,
    },
    .mcpwm0 = {
        .pwm_modula_enable = false,
        .freq = 3000,
        .duty = 5000,
        .pwm_type = USER_PWM2_CH,
        .pwm_output_state = PWM_STATE_CLOSE,
        .output_clk = CH0_CH0_PWM,
        .port[0] = IO_PORTA_06,
        .port[1] = IO_PORTA_13,
        .port[2] = IO_PORTA_14,
    },
    .mcpwm1 = {
        .pwm_modula_enable = TRUE,
        .freq = 40000,
        .duty = 5000,
        .pwm_type = USER_PWM3_CH,
        .pwm_output_state = PWM_STATE_CLOSE,
        .output_clk = CH2_CH1_PWM,
        .port[0] = IO_PORTB_01,
        .port[1] = -1,
        .port[2] = -1,
    },
    .mcpwm2 = {
        .pwm_modula_enable = false,
        .freq = 5000,
        .duty = 5000,
        .pwm_type = USER_PWM4_CH,
        .pwm_output_state = PWM_STATE_CLOSE,
        .output_clk = CH1_CH2_PWM,
        .port[0] = IO_PORTA_11,
        .port[1] = IO_PORTA_10,
        .port[2] = IO_PORTA_08,
    },
    .mcpwm3 = {
        .pwm_modula_enable = false,
        .freq = 6000,
        .duty = 5000,
        .pwm_type = USER_PWM5_CH,
        .pwm_output_state = PWM_STATE_CLOSE,
        .output_clk = CH3_CH3_PWM,
        .port[0] = IO_PORTA_12,
        .port[1] = IO_PORTB_00,
        .port[2] = IO_PORTB_01,
    },

};

/*----------------------------------------------------------------------------*/
/**@brief   设置PWM频率、占空比
   @param   pwm_var:pwm所有信息
   @return  无
   @note    如果如果需要移植该模块到其他系列,
            只需要修改set_pwm_timer_state,set_pwm_duty_and_freq,set_hw_port_iomap_reg函数
*/
/*----------------------------------------------------------------------------*/
void set_pwm_duty_and_freq(PWM_VAR *pwm_var)
{
    u16 timer_prd = sys_clock_get()/pwm_var->freq;
    u16 timer_cmp = (timer_prd*pwm_var->duty)/10000;
    switch (pwm_var->pwm_type)
    {
    case USER_PWM0_CH:
        {
            SFR(JL_TMR2->PRD,0,16,timer_prd);
            SFR(JL_TMR2->PWM0,0,16,timer_cmp);             
        }
        break;
    case USER_PWM1_CH:
        {
            SFR(JL_TMR2->PRD,0,16,timer_prd);
            SFR(JL_TMR2->PWM1,0,16,timer_cmp);             
        }
        break;
    case USER_PWM2_CH:
        {
            SFR(JL_PWM->TMR0_PR,0,16,timer_prd);
            SFR(JL_PWM->CH0_CMP,0,16,timer_cmp);             
        }
        break;
    case USER_PWM3_CH:
        {
            SFR(JL_PWM->TMR1_PR,0,16,timer_prd);
            SFR(JL_PWM->CH1_CMP,0,16,timer_cmp);             
        }
        break;
    case USER_PWM4_CH:
        {
            SFR(JL_PWM->TMR2_PR,0,16,timer_prd);
            SFR(JL_PWM->CH2_CMP,0,16,timer_cmp);             
        }
        break;
    case USER_PWM5_CH:
        {
            SFR(JL_PWM->TMR3_PR,0,16,timer_prd);
            SFR(JL_PWM->CH3_CMP,0,16,timer_cmp);            
        }
        break;    
    default:
        break;
    }
}

/*----------------------------------------------------------------------------*/
/**@brief   主要是配置硬件定时器寄存器,设置频率、占空等
   @param   cmd:开关PWM消息包括PWM_STATE_OPEN和PWM_STATE_CLOSE,
            pwm_var:pwm所有信息
   @return  无
   @note    如果如果需要移植该模块到其他系列,
            只需要修改set_pwm_timer_state,set_pwm_duty_and_freq,set_hw_port_iomap_reg函数
*/
/*----------------------------------------------------------------------------*/
static void set_pwm_timer_state(u16 cmd,PWM_VAR *pwm_var)
{    
    extern int lsb_clk_get();
    u32 timer_prd = lsb_clk_get()/pwm_var->freq;
    u32 timer_cmp = (timer_prd*pwm_var->duty)/10000;
    switch (pwm_var->pwm_type)
    {
    case USER_PWM0_CH:
        {
            if(cmd == PWM_STATE_OPEN){
                // SFR(JL_TMR2->CON,2,2,2); //选择时钟源
                SFR(JL_TMR2->CON,4,2,0); //选择时钟源
                SFR(JL_TMR2->PRD,0,16,(u16)timer_prd);
                SFR(JL_TMR2->PWM0,0,16,(u16)timer_cmp); 
                SFR(JL_TMR2->CON,0,2,1); //打开计数
                SFR(JL_TMR2->CON,8,1,1); //使能TIMER_PWM0
                SFR(JL_TMR2->CON,6,1,1); //清除中断请求标志
            }else if(cmd == PWM_STATE_CLOSE){
                SFR(JL_TMR2->CON,8,1,0); //使能TIMER_PWM0
                SFR(JL_TMR2->CON,0,2,0); //关闭计数
                SFR(JL_TMR2->CON,6,1,1); //清除中断请求标志
            }
        }
        break;
    case USER_PWM1_CH:
        {
            if(cmd == PWM_STATE_OPEN){
                // SFR(JL_TMR2->CON,2,2,2); //选择时钟源
                SFR(JL_TMR2->CON,4,2,0); //选择时钟源
                SFR(JL_TMR2->PRD,0,16,(u16)timer_prd);
                SFR(JL_TMR2->PWM1,0,16,(u16)timer_cmp);
                SFR(JL_TMR2->CON,0,2,1); //打开计数                
                SFR(JL_TMR2->CON,12,1,1); //使能TIMER_PWM1
                SFR(JL_TMR2->CON,6,1,1); //清除中断请求标志
            }else if(cmd == PWM_STATE_CLOSE){
                SFR(JL_TMR2->CON,12,1,0); //使能TIMER_PWM1
                SFR(JL_TMR2->CON,0,2,0); //关闭计数
                SFR(JL_TMR2->CON,6,1,1); //清除中断请求标志
            }
        }
        break;
    case USER_PWM2_CH:
        {
            if(cmd == PWM_STATE_OPEN){
                SFR(JL_PWM->PWMCON1,1,3,0);  //打开选择PWM_TIMER0
                SFR(JL_PWM->TMR0_PR,0,16,(u16)timer_prd);
                SFR(JL_PWM->CH0_CMP,0,16,(u16)timer_cmp);
                SFR(JL_TMR2->CON,0,2,1); //打开计数 
                SFR(JL_PWM->PWMCON0,8,1,1);  //打开pwm0_timer计时
                SFR(JL_PWM->PWMCON0,0,1,1);  //打开MCPWM0
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }else if(cmd == PWM_STATE_CLOSE){
                SFR(JL_PWM->PWMCON0,8,1,0);  //打开pwm0_timer计时
                SFR(JL_PWM->PWMCON0,0,1,0);  //关闭MCPWM0
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }
        }
        break;
    case USER_PWM3_CH:
        {
            if(cmd == PWM_STATE_OPEN){
                SFR(JL_PWM->PWMCON1,5,3,1);  //打开选择PWM_TIMER1
                SFR(JL_PWM->TMR1_PR,0,16,(u16)timer_prd);
                SFR(JL_PWM->CH1_CMP,0,16,(u16)timer_cmp);
                SFR(JL_PWM->PWMCON0,9,1,1);  //打开pwm1_timer计时
                SFR(JL_PWM->PWMCON0,1,1,1);  //打开MCPWM1
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }else if(cmd == PWM_STATE_CLOSE){
                SFR(JL_PWM->PWMCON0,9,1,0);  //打开pwm1_timer计时
                SFR(JL_PWM->PWMCON0,1,1,0);  //关闭MCPWM1
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }
        }
        break;
    case USER_PWM4_CH:
        {
            if(cmd == PWM_STATE_OPEN){
                SFR(JL_PWM->PWMCON1,9,3,2);  //打开选择PWM_TIMER2
                SFR(JL_PWM->TMR2_PR,0,16,(u16)timer_prd);
                SFR(JL_PWM->CH2_CMP,0,16,(u16)timer_cmp);
                SFR(JL_PWM->PWMCON0,10,1,1);  //打开pwm2_timer计时
                SFR(JL_PWM->PWMCON0,2,1,1);  //打开MCPWM2
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }else if(cmd == PWM_STATE_CLOSE){
                SFR(JL_PWM->PWMCON0,10,1,0);  //打开pwm2_timer计时
                SFR(JL_PWM->PWMCON0,2,1,0);  //打开MCPWM2
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }
        }
        break;
    case USER_PWM5_CH:
        {
            if(cmd == PWM_STATE_OPEN){
                SFR(JL_PWM->PWMCON1,13,3,3);  //打开选择PWM_TIMER3
                SFR(JL_PWM->TMR3_PR,0,16,(u16)timer_prd);
                SFR(JL_PWM->CH3_CMP,0,16,(u16)timer_cmp);
                SFR(JL_PWM->PWMCON0,11,1,1);  //打开pwm3_timer计时
                SFR(JL_PWM->PWMCON0,3,1,1);  //打开MCPWM3
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }else if(cmd == PWM_STATE_CLOSE){
                SFR(JL_PWM->PWMCON0,11,1,0);  //打开pwm3_timer计时
                SFR(JL_PWM->PWMCON0,3,1,0);  //关闭MCPWM3
                SFR(JL_PWM->TMR0_CON,5,1,1);  //清除中断请求标志
            }

        }
        break;
    default:
        break;
    }  
}

/*----------------------------------------------------------------------------*/
/**@brief   主要是配置硬件引脚是否输出PWM的寄存器配置
   @param   cmd:硬件引脚是否输出PWM消息包括PWM_STATE_OPEN和PWM_STATE_CLOSE,
            gpio：选择的引脚
   @return  无
   @note    如果如果需要移植该模块到其他系列,
            只需要修改set_pwm_timer_state,set_pwm_duty_and_freq,set_hw_port_iomap_reg函数
*/
/*----------------------------------------------------------------------------*/
static void set_hw_port_iomap_reg(u16 cmd,PWM_VAR *pwm_var)
{
    if(cmd == PWM_STATE_OPEN){
        if((pwm_var->pwm_type == USER_PWM0_CH)||(pwm_var->pwm_type == USER_PWM1_CH))
        {
            SFR(JL_IOMC->IOMC1, USER_PWM_HW_PORT_IOMAP_REG[pwm_var->pwm_type-USER_PWM0_CH], 1, 1);  //打开hw port
        }else{
            SFR(JL_IOMC->IOMC0, USER_PWM_HW_PORT_IOMAP_REG[pwm_var->pwm_type-USER_PWM0_CH], 1, 1);  //打开hw port
        }
    }else if(cmd == PWM_STATE_CLOSE){
        if((pwm_var->pwm_type == USER_PWM0_CH)||(pwm_var->pwm_type == USER_PWM1_CH))
        {
            SFR(JL_IOMC->IOMC1, USER_PWM_HW_PORT_IOMAP_REG[pwm_var->pwm_type-USER_PWM0_CH], 1, 0);  //打开hw port
        }else{
            SFR(JL_IOMC->IOMC0, USER_PWM_HW_PORT_IOMAP_REG[pwm_var->pwm_type-USER_PWM0_CH], 1, 0);  //打开hw port
        }
    }

}


/*----------------------------------------------------------------------------*/
/**@brief   设置映射和硬件引脚输出状态,判断引脚属于映射或硬件来进行操作,一般只有初始化和动态加载引脚会使用
            该函数用户不需要调用
   @param   cmd:开关PWM输出消息包括PWM_STATE_OPEN和PWM_STATE_CLOSE,
            gpio：选择的引脚
   @return  无
   @note    如果只是想开关某个引脚，调用pwm_gpio_pwm_state操作
*/
/*----------------------------------------------------------------------------*/
static u8 port_set_hw_and_iomap_state(u16 cmd,u16 gpio,PWM_VAR *pwm_var)
{
    if(gpio != USER_PWM_HW_PORT[pwm_var->pwm_type-USER_PWM0_CH]){
        if((output_clk_sel[pwm_var->output_clk/8] != pwm_var->output_clk)&&(output_clk_sel[pwm_var->output_clk/8] != -1))
        {
            log_info("output_ch %d already occupy\n",pwm_var->output_clk/8);
            return FALSE;
        }
        if(output_clk_sel[pwm_var->output_clk/8] == -1){
            output_clk_sel[pwm_var->output_clk/8] = pwm_var->output_clk;
        }        
    }
    if(pwm_var->pwm_type != USER_TIMER_NONE){
            log_info("pwm_type %d %d %d %d\n",pwm_var->pwm_type,cmd,gpio,USER_PWM_HW_PORT[pwm_var->pwm_type-USER_PWM0_CH]);
            if(cmd == PWM_STATE_OPEN){
                if(gpio != USER_PWM_HW_PORT[pwm_var->pwm_type-USER_PWM0_CH]){
                    log_info("gpio_output_channle %d %d \n",gpio,pwm_var->output_clk);
                    if(((pwm_var->output_clk/8 >= 2)&&(gpio < IO_PORTB_00))||((pwm_var->output_clk/8 < 2)&&(gpio >= IO_PORTB_00)))
                    {
                        log_info("port:%d to output ch %d err,Notice:PA口用OUTCHANNEL0/1 PB口用OUTCHANNEL2/3\n",gpio,pwm_var->output_clk/8); 
                        return FALSE;                       
                    }
                    #if UART_TX_OUTPUT_CH_EN&&UART_DEBUG
                    if(((UART_OUTPUT_CH_PORT < IO_PORTB_00)&&(pwm_var->output_clk/8 < 2))||((UART_OUTPUT_CH_PORT >= IO_PORTB_00)&&(pwm_var->output_clk/8 >= 2)))
                    {
                        log_info("printf output ch %d Covered,Notice:打印口映射被覆盖，如果要看打印先不要映射该通道\n",pwm_var->output_clk/8);
                    }
                    #endif
                    gpio_output_channle(gpio,pwm_var->output_clk);
                    if(gpio_output_channle_pwm_state[gpio] == PORT_CONFIG_NONE){
                        gpio_output_channle_pwm_state[gpio] = (pwm_var->output_clk/8)+1;
                        pwm_gpio_pwm_state(gpio,PORT_PWM_STATE_OPEN);
                    }else{
                        log_info("iomap port:%d err,port already iomap",gpio);
                    }
                }else{
                    pwm_gpio_pwm_state(gpio,PORT_PWM_STATE_OPEN);
                    set_hw_port_iomap_reg(cmd,pwm_var);
                }
            }else if(cmd == PWM_STATE_CLOSE){
                if(gpio != USER_PWM_HW_PORT[pwm_var->pwm_type-USER_PWM0_CH]){
                    if(gpio_output_channle_pwm_state[gpio] != PORT_CONFIG_NONE){
                        pwm_gpio_pwm_state(gpio,PORT_PWM_STATE_CLOSE);
                        gpio_output_channle_pwm_state[gpio] = PORT_CONFIG_NONE;
                    }else{
                        log_info("uniomap port:%d err,port not iomap",gpio);
                        return FALSE;
                    }
                }else{
                    pwm_gpio_pwm_state(gpio,PORT_PWM_STATE_CLOSE);
                    set_hw_port_iomap_reg(cmd,pwm_var);
                }
            }    
        return TRUE;    
    }else{
        return FALSE;
    }
}

/*----------------------------------------------------------------------------*/
/**@brief   开关引脚是否输出PWM,包括映射引脚以及硬件引脚,在初始化时候会去记录映射源，所以使用一致
   @param   cmd:打开或关闭引脚PWM输出消息包括PORT_PWM_STATE_OPEN和PORT_PWM_STATE_CLOSE,
            CHx消息一般不使用,如果不使用模块初始化引脚和加载引脚,可以调用CHx消息去映射想要的PWM
            gpio：选择的引脚
   @return  无
   @note    如果只是想开关某个引脚，建议使用该函数来设置,如果使用寄存器开关可以参考该函数
*/
/*----------------------------------------------------------------------------*/
void pwm_gpio_pwm_state(u16 gpio,u16 cmd)
{
    log_info("pwm_gpio_pwm_state gpio:%d cmd:%d\n",gpio,cmd);
    switch (cmd)
    {
    case PORT_OUTPUT_CH0_STATE_OPEN:
    case PORT_OUTPUT_CH1_STATE_OPEN:
    case PORT_OUTPUT_CH2_STATE_OPEN:
    case PORT_OUTPUT_CH3_STATE_OPEN:
        {
            gpio_set_direction(gpio, 0);
            gpio_set_pull_up(gpio, 1);
            gpio_set_pull_down(gpio, 1);
            gpio_write(gpio, (cmd-PORT_OUTPUT_CH0_STATE_OPEN)&BIT(1));
            gpio_set_die(gpio, (cmd-PORT_OUTPUT_CH0_STATE_OPEN)&BIT(0));
        }
        break;
    case PORT_OUTPUT_CH0_STATE_CLOSE:
    case PORT_OUTPUT_CH1_STATE_CLOSE:
    case PORT_OUTPUT_CH2_STATE_CLOSE:
    case PORT_OUTPUT_CH3_STATE_CLOSE:
        {
            gpio_set_direction(gpio, 1);
            gpio_set_pull_up(gpio, 0);
            gpio_set_pull_down(gpio, 0);
            gpio_write(gpio,0);
            gpio_set_die(gpio,0);
        }
        break;
    case PORT_PWM_STATE_OPEN:
        {
            if(gpio_output_channle_pwm_state[gpio] != PORT_CONFIG_NONE){
                pwm_gpio_pwm_state(gpio,((gpio_output_channle_pwm_state[gpio]-PORT_OUTPUT_CH0_STATE_OPEN)+PORT_OUTPUT_CH0_STATE_OPEN));
            }else{
                gpio_set_die(gpio,1);
                gpio_set_pull_up(gpio,0);
                gpio_set_pull_down(gpio,0);
                gpio_set_direction(gpio,0);
            }
        }
    break;
    case PORT_PWM_STATE_CLOSE:
        {
            if(gpio_output_channle_pwm_state[gpio] != PORT_CONFIG_NONE){
                pwm_gpio_pwm_state(gpio,((gpio_output_channle_pwm_state[gpio]-PORT_OUTPUT_CH0_STATE_OPEN)+PORT_OUTPUT_CH0_STATE_CLOSE));
            }else{
                gpio_set_die(gpio,1);
                gpio_set_pull_up(gpio,0);
                gpio_set_pull_down(gpio,0);
                gpio_set_direction(gpio,1);
            }
        }
    break;
    default:
        break;
    }
}

/*----------------------------------------------------------------------------*/
/**@brief   开关PWM函数,可以选择开关哪路PWM
   @param   cmd:开关PWM消息包括PWM_STATE_OPEN和PWM_STATE_CLOSE
            pwm_var:该参数主要包含PWM所有信息
   @return  无
   @note    无
*/
/*----------------------------------------------------------------------------*/
void pwm_ctr_pwm_state(u16 cmd,PWM_VAR *pwm_var)
{
    if(!pwm_var->pwm_modula_enable){
        log_info("pwm_modula_enable not open %d\n",pwm_var->pwm_type);
        return;
    }
    if(!pwm_var->freq){
        log_info("%d freq err\n",pwm_var->pwm_type);
        return;
    }
    if(pwm_var->pwm_type != USER_TIMER_NONE){
        set_pwm_timer_state(cmd,pwm_var);
        for(u8 i = 0;i < PWM_PORT_MAX;i++)
        {
            if(pwm_var->port[i] != -1){
                port_set_hw_and_iomap_state(cmd,pwm_var->port[i],pwm_var);
            }
        }        
        pwm_var->pwm_output_state = cmd;
    }else{
        log_info("pwm not config,post USER_TIMER_NONE\n");        
    }
}

/*----------------------------------------------------------------------------*/
/**@brief   动态加载引脚PWM函数,一般初始化完PWM模块后如果需要加载其他引脚或者卸载引脚可以用这个函数
   @param   cmd:加载卸载消息包括PWM_STATE_ADD_PORT和PWM_STATE_DEL_PORT
            gpio：选择的引脚
            pwm_var:该参数主要包含PWM所有信息
   @return  无
   @note    使用该函数过程需要注意PWM_PORT_MAX大小
*/
/*----------------------------------------------------------------------------*/
void pwm_port_dynamic_loading(u16 cmd,u16 gpio,PWM_VAR *pwm_var)
{
    log_info("pwm_port_dynamic_loading\n");
    u8 i = 0;
    if(!pwm_var->pwm_modula_enable){
        log_info("pwm_modula_enable not open pwm_type:%d\n",pwm_var->pwm_type);
        return;
    }
    switch (cmd)
    {
    case PWM_STATE_ADD_PORT:
        {
            for(i = 0;i < PWM_PORT_MAX;i++){
                if(pwm_var->port[i] == gpio){
                    log_info("pwm_modula_list existence pwm_type:%d,port:%d\n",pwm_var->pwm_type,gpio);
                    return;
                }
            }
            for(i = 0;i < PWM_PORT_MAX;i++)
            {
                if(pwm_var->port[i] == -1){break;}
                if(i == PWM_PORT_MAX-1){
                    log_info("add_port err iomap_port full please modify PWM_PORT_MAX size\n");
                    return;
                }
            }
            if(pwm_var->pwm_output_state == PWM_STATE_OPEN){
                if(port_set_hw_and_iomap_state(PWM_STATE_OPEN,gpio,pwm_var)){
                    log_info("pwm_state_open add_port_success:%d\n",gpio);
                    pwm_var->port[i] = gpio;
                }else{
                    log_info("pwm_state_open add_port_fail:%d\n",gpio);                    
                }
            }else if(pwm_var->pwm_output_state == PWM_STATE_CLOSE){
                pwm_var->port[i] = gpio;
                log_info("pwm_state_close add_port_success:%d\n",gpio);
            }
        }
        break;
    case PWM_STATE_DEL_PORT:
        {
            for(i = 0;i < PWM_PORT_MAX;i++){
                if(pwm_var->port[i] == gpio){
                    break;
                }
                if(i == PWM_PORT_MAX-1){
                    log_info("del_port err iomap_port_list not port:%d\n",gpio);
                    return;
                }
            }
            for(i = 0;i < PWM_PORT_MAX;i++)
            {
                if(pwm_var->port[i] == -1){break;}
                if(i == PWM_PORT_MAX-1){
                    log_info("add_port err iomap_port full please modify PWM_PORT_MAX size\n");
                    return;
                }
            }
            if(pwm_var->pwm_output_state == PWM_STATE_OPEN){
                if(port_set_hw_and_iomap_state(PWM_STATE_CLOSE,gpio,pwm_var)){
                    log_info("pwm_state_open del_port:%d\n",gpio);
                    pwm_var->port[i] = -1;
                }else{
                    log_info("pwm_state_open del_port_fail:%d\n",gpio);                    
                }
            }else if(pwm_var->pwm_output_state == PWM_STATE_CLOSE){
                pwm_var->port[i] = -1;
                log_info("pwm_state_close del_port:%d\n",gpio);
            }

        }
        break;
    default:
        break;
    }
}

/*----------------------------------------------------------------------------*/
/**@brief   初始化六路PWM函数,主要是用来介绍如何调用该模块
   @param   无
   @return  无
   @note    自己可以根据需要去选择打开多少路
*/
/*----------------------------------------------------------------------------*/
void pwm_ctr_init(void)
{
    // pwm_ctr_pwm_state(PWM_STATE_OPEN,&all_pwm_var.timer2_pwm0);
    // pwm_ctr_pwm_state(PWM_STATE_OPEN,&all_pwm_var.timer2_pwm1);
    // pwm_ctr_pwm_state(PWM_STATE_OPEN,&all_pwm_var.mcpwm0);
    pwm_ctr_pwm_state(PWM_STATE_OPEN,&all_pwm_var.mcpwm1);
    // pwm_ctr_pwm_state(PWM_STATE_OPEN,&all_pwm_var.mcpwm2);
    // pwm_ctr_pwm_state(PWM_STATE_OPEN,&all_pwm_var.mcpwm3);
}

